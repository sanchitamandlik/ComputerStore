package com.edu.SpringBootLaptopApp.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.edu.SpringBootLaptopApp.entity.Laptop;


public interface LaptopRepository extends JpaRepository<Laptop,Long> {

	//List<Laptop> findBylaptop_Type(String laptop_Type);
	
	//@Query("select l from Laptop l where l.laptop_Type = :name ");
   // List<Laptop> findLaptopBylaptop_Type(@Param("name") String laptop_Type);


}



