
package com.edu.SpringBootLaptopApp.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.edu.SpringBootLaptopApp.entity.Laptop;
import com.edu.SpringBootLaptopApp.exception.ResourceNotFound;
import com.edu.SpringBootLaptopApp.repository.LaptopRepository;
import com.edu.SpringBootLaptopApp.service.LaptopService;

@Service
public class LaptopServiceImpl implements LaptopService{

	private LaptopRepository laptopRepository;
	
	
	public LaptopServiceImpl(LaptopRepository laptopRepository) {
		super();
		this.laptopRepository = laptopRepository;
	}

	@Override
	public Laptop saveLaptop(Laptop laptop) {
		return laptopRepository.save(laptop);
	}


	@Override
	public List<Laptop> getAllLaptop() {
		return laptopRepository.findAll();
		
	}


	@Override
	public Laptop getLaptopById(long id) {
		Optional<Laptop> laptop = laptopRepository.findById(id);
		if(laptop.isPresent()) {
			return laptop.get();
		}
		else {
          
			throw new ResourceNotFound("Laptop","Id",id);
		}
		
	}
	

	@Override
	public Laptop updateLaptop(Laptop laptop, long id) {
		Laptop lp = new Laptop();
		
	 try {
		   lp = laptopRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Laptop","Id",id));
	 } catch (ResourceNotFound e) {
		
		e.printStackTrace();
	}
	 String name=laptop.getLaptop_Type();
	 lp.setLaptop_Price(laptop.getLaptop_Price());
	 lp.setLaptop_Company(laptop.getLaptop_Company());
	 lp.setLaptop_Type(name);
	
	 laptopRepository.save(lp);
	 		return lp;
	}
	@Override 
	public void deleteLaptop(long id) {
		 laptopRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Laptop","Id",id));
		 laptopRepository.deleteById(id);
	}
	//@Override
	//public List<Laptop> getlaptopBylaptop_Type(String laptop_Type) {
		//return (laptopRepository).findBylaptop_Type(laptop_Type);
    // }

	//@Override
	//public List<Laptop> getLaptopBylaptop_Type(String laptop_Type) {
		// TODO Auto-generated method stub
		//return null;
	//}
	
}
