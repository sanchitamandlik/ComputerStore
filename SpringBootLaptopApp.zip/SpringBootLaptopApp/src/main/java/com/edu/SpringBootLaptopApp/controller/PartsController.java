

package com.edu.SpringBootLaptopApp.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.SpringBootLaptopApp.ServiceImpl.PartsServiceImpl;
import com.edu.SpringBootLaptopApp.entity.Parts;
import com.edu.SpringBootLaptopApp.service.PartsService;


	@Controller
	@RequestMapping("/api/parts")
	public class PartsController {
		private PartsService partsService;

		public PartsController(PartsService partsService) {
			super();
			this.partsService = partsService;
		}
		
		@PostMapping
		public ResponseEntity<Parts> saveParts(@RequestBody Parts parts) {
			return new ResponseEntity<Parts>(partsService.saveparts(parts),HttpStatus.CREATED);
		}
		

		@GetMapping
		public List<Parts> getAllParts()
		{
			return partsService.getAllParts();
		}
		@GetMapping("{id}")
		public ResponseEntity<Parts>getPartsById(@PathVariable("id") long id) {
			return new ResponseEntity(partsService.getPartsById(id), HttpStatus.OK);
		}
		
		@PutMapping("{id}")
		public ResponseEntity<Parts> updateParts(@PathVariable("id") long id, @RequestBody Parts parts){
			
			//return new ResponseEntity<Parts>(HttpStatus.OK);
			return new ResponseEntity<Parts>(partsService.updateParts(parts, id),HttpStatus.OK);

		}
		
		@DeleteMapping("{id}")
		public ResponseEntity<String> deleteParts(@PathVariable("id")long id){
			partsService.deleteParts(id);
			return new ResponseEntity<String>("Parts record deleted",HttpStatus.OK);
		}
	}



