package com.edu.SpringBootLaptopApp.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.edu.SpringBootLaptopApp.entity.Parts;
import com.edu.SpringBootLaptopApp.exception.ResourceNotFound;
import com.edu.SpringBootLaptopApp.repository.PartsRepository;
import com.edu.SpringBootLaptopApp.repository.PartsService;

import java.util.Optional;

import com.edu.SpringBootLaptopApp.entity.Parts;


@Service
public class PartsServiceImpl implements PartsService{

	private PartsRepository partsRepository;
	
	
	public PartsServiceImpl(PartsRepository partsRepository) {
		super();
		this.partsRepository = partsRepository;
	}

	@Override
	public Parts saveParts(Parts parts) {
		return partsRepository.save(parts);
	}


	@Override
	public List<Parts> getAllParts() {
		return partsRepository.findAll();
		
	}


	@Override
	public Parts getPartsById(long id) {
		Optional<Parts> parts = partsRepository.findById(id);
		if(parts.isPresent()) {
			return parts.get();
		}
		else {
          
			throw new ResourceNotFound("Parts","Id",id);
		}
		
	}
	

	@Override
	public Parts updateParts(Parts parts, long id) {
		Parts lp = new Parts();
		
	 try {
		   lp = partsRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Parts","Id",id));
	 } catch (ResourceNotFound e) {
		
		e.printStackTrace();
	}
	 lp.setPartName(parts.getPartName());
	 lp.setPartType(parts.getPartType());
	 lp.setPartDescription(parts.getPartDescription());
	
	 partsRepository.save(lp);
	 		return lp;
	}
	@Override 
	public void deleteParts(long id) {
		 partsRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Parts","Id",id));
		 partsRepository.deleteById(id);
	}

	@Override
	public Parts saveparts(Parts parts) {
		// TODO Auto-generated method stub
		return null;
	}


}



