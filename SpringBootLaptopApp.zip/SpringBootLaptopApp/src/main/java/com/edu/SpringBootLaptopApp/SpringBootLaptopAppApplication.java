package com.edu.SpringBootLaptopApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLaptopAppApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringBootLaptopAppApplication.class, args);
		
	}

}
