package com.edu.SpringBootLaptopApp.service;
import java.util.List;

import com.edu.SpringBootLaptopApp.entity.Parts;

public interface PartsService {
	
		Parts saveparts(Parts parts);
		List<Parts>getAllParts();
		Parts getPartsById(long id) ;
			
		
		Parts updateParts(Parts parts ,long id);
		void deleteParts(long id);
		Parts saveParts(Parts parts);
		
		
		

	


}
