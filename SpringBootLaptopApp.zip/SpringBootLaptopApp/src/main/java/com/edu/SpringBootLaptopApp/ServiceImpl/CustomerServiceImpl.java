package com.edu.SpringBootLaptopApp.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.edu.SpringBootLaptopApp.entity.Customer;
import com.edu.SpringBootLaptopApp.exception.ResourceNotFound;
import com.edu.SpringBootLaptopApp.repository.CustomerRepository;
import com.edu.SpringBootLaptopApp.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{

	private CustomerRepository customerRepository;
	
	
	public CustomerServiceImpl(CustomerRepository customerRepository) {
		super();
		this.customerRepository = customerRepository;
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		return customerRepository.save(customer);
	}


	@Override
	public List<Customer> getAllCustomer() {
		return customerRepository.findAll();
		
	}


	@Override
	public Customer getCustomerById(long id) {
		Optional<Customer> customer = customerRepository.findById(id);
		if(customer.isPresent()) {
			return customer.get();
		}
		else {
          
			throw new ResourceNotFound("Customer","Id",id);
		}
		
	}
	

	@Override
	public Customer updateCustomer(Customer customer, long id) {
		Customer lp = new Customer();
		
	 try {
		   lp = customerRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Customer","Id",id));
	 } catch (ResourceNotFound e) {
		
		e.printStackTrace();
	}
	 lp.setCustomerName(customer.getCustomerName());
	 lp.setUsername(customer.getUsername());
	 lp.setPassword(customer.getPassword());
	 lp.setEmail(customer.getEmail());
	
	 customerRepository.save(lp);
	 		return lp;
	}
	@Override 
	public void deleteCustomer(long id) {
		 customerRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Customer","Id",id));
		 customerRepository.deleteById(id);
	}

	@Override
	public Customer savecustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}


}



