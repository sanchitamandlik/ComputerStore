package com.edu.SpringBootLaptopApp.service;

import java.util.List;

import com.edu.SpringBootLaptopApp.entity.Laptop;

public interface LaptopService {
	Laptop saveLaptop(Laptop laptop);
	List<Laptop>getAllLaptop();
	Laptop getLaptopById(long id) ;
		
	
	Laptop updateLaptop(Laptop laptop ,long id);
	void deleteLaptop(long id);
	//List<Laptop> getLaptopBylaptop_Type(String laptop_Type);
	//List<Laptop> getlaptopBylaptop_Type(String laptop_Type);
	
	
	

}

