package com.edu.SpringBootLaptopApp.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.edu.SpringBootLaptopApp.entity.Laptop;
import com.edu.SpringBootLaptopApp.service.LaptopService;

@Controller
@RequestMapping("/api/laptop")
public class LaptopController {
	private LaptopService laptopService;

	public LaptopController(LaptopService laptopService) {
		super();
		this.laptopService = laptopService;
	}
	
	@PostMapping
	public ResponseEntity<Laptop> saveLaptop(@RequestBody Laptop laptop) {
		return new ResponseEntity<Laptop>(laptopService.saveLaptop(laptop),HttpStatus.CREATED);
	}
	

	@GetMapping
	public List<Laptop> getAllLaptop()
	{
		return laptopService.getAllLaptop();
	}
	@GetMapping("{id}")
	public ResponseEntity<Laptop>getLaptopById(@PathVariable("id") long id) {
		return new ResponseEntity(laptopService.getLaptopById(id), HttpStatus.OK);
	}
	//@GetMapping("/laptopByLaptop_Type/{laptop_Type}")
	//public List<Laptop> getlaptopBylaptop_Type(@PathVariable("laptop_Type") String laptop_Type){
	//	return laptopService.getLaptopBylaptop_Type(laptop_Type);
	//}
	

	@PutMapping("{id}")
	public ResponseEntity<Laptop> updateLaptop(@PathVariable("id") long id, @RequestBody Laptop laptop){
		
		return new ResponseEntity<Laptop>(laptopService.updateLaptop(laptop, id),HttpStatus.OK);
		
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteLaptop(@PathVariable("id")long id){
		laptopService.deleteLaptop(id);
		return new ResponseEntity<String>("Laptop record deleted",HttpStatus.OK);
	}
}
