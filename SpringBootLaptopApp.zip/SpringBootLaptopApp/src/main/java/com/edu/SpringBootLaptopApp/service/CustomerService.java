package com.edu.SpringBootLaptopApp.service;

import java.util.List;

import com.edu.SpringBootLaptopApp.entity.Customer;

public interface CustomerService {

	Customer getCustomerById(long id);

	List<Customer> getAllCustomer();

	Customer saveCustomer(Customer customer);

	Customer updateCustomer(Customer customer, long id);

	void deleteCustomer(long id);

	Customer savecustomer(Customer customer);

}
