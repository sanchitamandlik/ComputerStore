package com.edu.SpringBootLaptopApp.entity;
import java.beans.Transient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import lombok.Data;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.Data;
@Entity
@Table(name="laptoptbl")
@Data
public class Laptop {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Long id;
	@Column(name="laptop_Price")
	private float laptop_Price;
	@Column(name="laptop_Company")
	private String laptop_Company;
	@Column(name="laptop_Type")
	private String laptop_Type;



}

